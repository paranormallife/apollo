
<div class="content-width post-content ' . $intro . '">
    
    <h1>Error 404: Not Found</h1>
    <h2>Sorry, we could't find what you're looking for.</h2>
    <p>You may have entered an incorrect URL or clicked a broken link.</p>
    <p>You can return to the <a href=" <?= get_bloginfo('wpurl'); ?>">homepage</a> or try a <a href="#" onclick="searchToggle()">search</a>.</p>
    
</div>