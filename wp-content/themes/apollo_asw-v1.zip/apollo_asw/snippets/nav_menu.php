<div class="main-menu-container">
    <?php wp_nav_menu( array( 'theme_location' => 'nav1' ) ); ?>
</div>
