<div class="search-form-container">
    <form method="get" class="footer-search" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
        <input type="text" class="field" name="s" id="s" placeholder="Nachocaster" />
        <button class="submit" name="submit" id="searchsubmit"><ion-icon name="search"></ion-icon> <span>Search This Site</span></button>
    </form>
</div>